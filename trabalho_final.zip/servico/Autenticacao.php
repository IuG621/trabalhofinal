<?php


if ( ! isset($_SESSION["autenticado"]) ){
    echo "
    <script>
    window.location.replace(https://guizoteste.000webhostapp.com/Trabalho_Final/indexfinal.html
    );
    </script>
    ";
    
}

?>